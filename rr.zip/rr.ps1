# Define the path to the MP4 file
$videoPath = "$env:TMP\rr\rr.mp4"

# Create a Windows Media Player COM object
$wmp = New-Object -ComObject WMPlayer.OCX

# Set volume to 30%
$wmp.settings.volume = 30

# Open the video file
$wmp.URL = $videoPath

# Make the player fullscreen
$wmp.fullScreen = $true

# Play the video
$wmp.controls.play()

# Wait for the video to finish
while ($wmp.playState -ne 1) {
    Start-Sleep -Seconds 1
}

# Release the COM object
[System.Runtime.Interopservices.Marshal]::ReleaseComObject($wmp) | Out-Null
